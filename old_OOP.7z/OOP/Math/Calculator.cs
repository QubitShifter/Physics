﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_1
{
    abstract class Calculator
    {
        public abstract void CalculateSum();
    }
}
